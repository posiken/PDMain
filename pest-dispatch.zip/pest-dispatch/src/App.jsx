import { useState, useEffect, useCallback, useRef } from "react";

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const STATUS_ORDER = { available: 0, "on-call": 1, "off-duty": 2 };
const TECH_TYPES   = ["GHP", "Lawn", "Termite", "Supervisor"];
const TYPE_CFG     = {
  GHP:        { color:"#38bdf8", bg:"rgba(56,189,248,.13)",  bd:"rgba(56,189,248,.32)"  },
  Lawn:       { color:"#4ade80", bg:"rgba(74,222,128,.13)",  bd:"rgba(74,222,128,.32)"  },
  Termite:    { color:"#fb923c", bg:"rgba(251,146,60,.13)",  bd:"rgba(251,146,60,.32)"  },
  Supervisor: { color:"#c084fc", bg:"rgba(192,132,252,.13)", bd:"rgba(192,132,252,.32)" },
};

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const uid = () => "t" + Date.now().toString(36) + Math.random().toString(36).slice(2,5);
const mid = () => "m" + Date.now().toString(36);
const ini = n  => n.trim().split(/\s+/).map(w=>w[0]||"").join("").toUpperCase().slice(0,2)||"??";

// ─── API HELPERS ──────────────────────────────────────────────────────────────
const api = {
  getTechs: ()              => fetch("/api/techs").then(r=>r.json()),
  saveTechs:(techs, code)   => fetch("/api/techs",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({techs,code})}).then(r=>r.json()),
  auth:     (body)          => fetch("/api/auth",  {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}).then(r=>r.json()),
};

// ─── CSS ──────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;900&family=DM+Mono:wght@400;500&family=Barlow:wght@400;500;600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

.app{min-height:100vh;background:#090e1a;color:#dde3f0;font-family:'Barlow',sans-serif;
  background-image:radial-gradient(ellipse at 18% 60%,rgba(245,158,11,.05) 0%,transparent 55%),
  radial-gradient(ellipse at 82% 15%,rgba(34,197,94,.03) 0%,transparent 50%);}

.top-bar{display:flex;align-items:center;justify-content:space-between;padding:13px 24px;
  border-bottom:1px solid #151e30;background:rgba(9,14,26,.97);backdrop-filter:blur(12px);
  position:sticky;top:0;z-index:99;}
.brand{display:flex;align-items:center;gap:10px;}
.brand-icon{width:32px;height:32px;background:#f59e0b;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:15px;}
.brand-name{font-family:'Barlow Condensed',sans-serif;font-size:18px;font-weight:700;letter-spacing:.06em;color:#e2e8f0;}
.brand-name span{color:#f59e0b;}
.nav-pill{padding:7px 15px;border-radius:6px;border:1px solid #151e30;background:transparent;color:#64748b;
  font-family:'Barlow',sans-serif;font-size:13px;font-weight:500;cursor:pointer;transition:all .18s;}
.nav-pill:hover{border-color:#f59e0b;color:#f59e0b;}
.nav-active{background:rgba(245,158,11,.1);border-color:#f59e0b!important;color:#f59e0b!important;}

.search-hero{max-width:600px;margin:60px auto 0;padding:0 20px;text-align:center;}
.hero-eyebrow{font-family:'DM Mono',monospace;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:#f59e0b;margin-bottom:12px;}
.hero-title{font-family:'Barlow Condensed',sans-serif;font-size:clamp(44px,8vw,68px);font-weight:900;line-height:.95;margin-bottom:12px;letter-spacing:-.02em;}
.hero-sub{color:#3d5068;font-size:15px;margin-bottom:28px;line-height:1.6;}
.search-bar{display:flex;border:1.5px solid #151e30;border-radius:10px;overflow:hidden;background:#0d1322;transition:border-color .2s,box-shadow .2s;}
.search-bar:focus-within{border-color:#f59e0b;box-shadow:0 0 0 3px rgba(245,158,11,.08);}
.zip-input{flex:1;padding:16px 20px;font-family:'DM Mono',monospace;font-size:28px;font-weight:500;letter-spacing:.15em;background:transparent;border:none;outline:none;color:#e2e8f0;}
.zip-input::placeholder{color:#1c2b3d;}
.type-section{margin-top:14px;}
.type-label{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.13em;text-transform:uppercase;color:#3d5068;margin-bottom:10px;text-align:left;}
.type-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;}
.type-btn{padding:16px 8px;border-radius:9px;border:1.5px solid #151e30;background:#0d1322;color:#3d5068;
  cursor:pointer;transition:all .2s;display:flex;flex-direction:column;align-items:center;gap:5px;}
.type-btn:hover:not(:disabled){border-color:#263a52;color:#64748b;transform:translateY(-1px);}
.type-btn:disabled{opacity:.35;cursor:not-allowed;}
.type-btn-label{font-family:'Barlow Condensed',sans-serif;font-size:17px;font-weight:900;letter-spacing:.04em;}
.type-btn-sub{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.08em;text-transform:uppercase;text-align:center;}
.type-btn.ghp-active {border-color:rgba(56,189,248,.55);background:rgba(56,189,248,.1);color:#38bdf8;}
.type-btn.lawn-active{border-color:rgba(74,222,128,.55);background:rgba(74,222,128,.1);color:#4ade80;}
.type-btn.tmte-active{border-color:rgba(251,146,60,.55); background:rgba(251,146,60,.1);color:#fb923c;}
.type-btn.spvr-active{border-color:rgba(192,132,252,.55);background:rgba(192,132,252,.1);color:#c084fc;}
.results-wrap{max-width:600px;margin:24px auto 0;padding:0 20px 60px;}
.results-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #151e30;}
.results-label{font-family:'DM Mono',monospace;font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:#3d5068;}

.tech-card{background:#0d1322;border:1px solid #151e30;border-radius:9px;padding:18px;margin-bottom:9px;
  display:flex;gap:14px;animation:slideIn .3s ease both;transition:border-color .2s,transform .15s;}
.tech-card:hover{border-color:rgba(245,158,11,.3);transform:translateY(-1px);}
@keyframes slideIn{from{opacity:0;transform:translateY(9px);}to{opacity:1;transform:translateY(0);}}
.tech-avatar{width:44px;height:44px;border-radius:50%;background:#151e30;border:2px solid #1e2e43;
  display:flex;align-items:center;justify-content:center;font-family:'Barlow Condensed',sans-serif;font-size:16px;font-weight:700;color:#f59e0b;flex-shrink:0;}
.tech-name{font-family:'Barlow Condensed',sans-serif;font-size:21px;font-weight:700;}
.tech-phone{display:block;font-family:'DM Mono',monospace;font-size:13px;color:#94a3b8;text-decoration:none;margin-bottom:7px;}
.tech-phone:hover{color:#f59e0b;}
.tech-notes{font-size:13px;color:#3d5068;margin-bottom:8px;}
.tag-row{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:7px;}
.zip-tags{display:flex;flex-wrap:wrap;gap:5px;}
.zip-tag{font-family:'DM Mono',monospace;font-size:11px;padding:2px 8px;background:#111a28;border:1px solid #1a2a3d;border-radius:4px;color:#3d5068;}
.zip-hl{background:rgba(245,158,11,.1);border-color:rgba(245,158,11,.32);color:#f59e0b;font-weight:500;}
.empty-state{text-align:center;padding:52px 20px;}
.empty-icon{font-size:42px;margin-bottom:13px;}
.empty-title{font-family:'Barlow Condensed',sans-serif;font-size:22px;font-weight:700;margin-bottom:7px;}
.empty-text{color:#3d5068;font-size:14px;line-height:1.6;max-width:300px;margin:0 auto;}

.admin-view{max-width:980px;margin:0 auto;padding:32px 20px 60px;}
.admin-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;}
.admin-head-left{display:flex;flex-direction:column;gap:5px;}
.admin-title{font-family:'Barlow Condensed',sans-serif;font-size:30px;font-weight:900;}
.admin-meta{font-family:'DM Mono',monospace;font-size:11px;color:#3d5068;letter-spacing:.08em;}
.admin-meta span{color:#f59e0b;}
.admin-head-right{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.session-badge{display:flex;align-items:center;gap:7px;background:#0d1322;border:1px solid #151e30;
  border-radius:20px;padding:5px 12px;font-family:'DM Mono',monospace;font-size:11px;color:#64748b;letter-spacing:.06em;}
.session-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;}
.btn-signout{padding:6px 13px;background:transparent;border:1px solid #151e30;border-radius:6px;
  color:#3d5068;font-size:12px;cursor:pointer;transition:all .18s;font-family:'Barlow',sans-serif;}
.btn-signout:hover{border-color:rgba(239,68,68,.4);color:#ef4444;}
.btn-add{padding:9px 18px;background:#f59e0b;border:none;border-radius:6px;color:#090e1a;
  font-family:'Barlow Condensed',sans-serif;font-size:14px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;cursor:pointer;transition:background .18s;}
.btn-add:hover{background:#fbbf24;}
.btn-outline{padding:7px 14px;background:transparent;border:1px solid #1e2e43;border-radius:6px;
  color:#64748b;font-family:'Barlow',sans-serif;font-size:13px;font-weight:500;cursor:pointer;transition:all .18s;display:flex;align-items:center;gap:6px;}
.btn-outline:hover{border-color:#f59e0b;color:#f59e0b;}
.admin-tabs{display:flex;gap:2px;margin-bottom:24px;border-bottom:1px solid #151e30;}
.admin-tab{padding:10px 18px;background:transparent;border:none;border-bottom:2px solid transparent;
  color:#3d5068;font-family:'Barlow',sans-serif;font-size:14px;font-weight:500;cursor:pointer;transition:all .18s;margin-bottom:-1px;}
.admin-tab:hover{color:#94a3b8;}
.tab-active{color:#f59e0b!important;border-bottom-color:#f59e0b!important;}
.import-banner{background:#0d1322;border:1px solid rgba(245,158,11,.3);border-radius:9px;padding:16px 20px;margin-bottom:20px;animation:slideIn .25s ease both;}
.import-banner-title{font-family:'Barlow Condensed',sans-serif;font-size:17px;font-weight:700;margin-bottom:4px;}
.import-banner-sub{font-size:13px;color:#64748b;margin-bottom:14px;line-height:1.5;}
.import-banner-actions{display:flex;gap:8px;}

/* save status toast */
.save-toast{display:flex;align-items:center;gap:8px;font-family:'DM Mono',monospace;font-size:11px;
  letter-spacing:.06em;padding:5px 12px;border-radius:6px;border:1px solid transparent;transition:all .3s;}
.save-saving{color:#f59e0b;border-color:rgba(245,158,11,.25);background:rgba(245,158,11,.08);}
.save-ok    {color:#22c55e;border-color:rgba(34,197,94,.25); background:rgba(34,197,94,.08);}
.save-err   {color:#ef4444;border-color:rgba(239,68,68,.25); background:rgba(239,68,68,.08);}

.table-wrap{border:1px solid #151e30;border-radius:9px;overflow:hidden;}
.tech-table{width:100%;border-collapse:collapse;}
.tech-table th{background:#0b1120;padding:10px 14px;text-align:left;font-family:'DM Mono',monospace;
  font-size:9px;font-weight:500;letter-spacing:.14em;text-transform:uppercase;color:#3d5068;border-bottom:1px solid #151e30;}
.tech-table td{padding:12px 14px;border-bottom:1px solid #151e30;vertical-align:middle;}
.tech-table tr:last-child td{border-bottom:none;}
.tech-table tbody tr:hover td{background:#0b1120;}
.row-avatar{width:30px;height:30px;border-radius:50%;background:#151e30;flex-shrink:0;display:flex;
  align-items:center;justify-content:center;font-family:'Barlow Condensed',sans-serif;font-size:12px;font-weight:700;color:#f59e0b;}
.btn-edit{padding:5px 12px;background:transparent;border:1px solid #1e2e43;border-radius:5px;
  color:#94a3b8;font-size:12px;cursor:pointer;font-family:'Barlow',sans-serif;transition:all .18s;}
.btn-edit:hover{border-color:#f59e0b;color:#f59e0b;}
.btn-del{padding:5px 12px;background:transparent;border:1px solid rgba(239,68,68,.2);border-radius:5px;
  color:#ef4444;font-size:12px;cursor:pointer;font-family:'Barlow',sans-serif;transition:all .18s;}
.btn-del:hover{background:rgba(239,68,68,.08);}
.btn-del-confirm{padding:5px 12px;background:rgba(239,68,68,.15);border:1px solid #ef4444;border-radius:5px;
  color:#ef4444;font-size:12px;cursor:pointer;font-family:'Barlow',sans-serif;font-weight:600;animation:pulse .6s ease infinite alternate;}
@keyframes pulse{from{opacity:.8;}to{opacity:1;}}

.code-section{background:#0d1322;border:1px solid #151e30;border-radius:9px;padding:22px;}
.code-section+.code-section{margin-top:20px;}
.code-section-title{font-family:'Barlow Condensed',sans-serif;font-size:19px;font-weight:700;margin-bottom:3px;}
.code-section-sub{font-size:13px;color:#3d5068;margin-bottom:16px;line-height:1.5;}
.code-row-display{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
.code-masked{font-family:'DM Mono',monospace;font-size:16px;letter-spacing:.12em;color:#94a3b8;}
.change-form-wrap{background:#090e1a;border:1px solid #151e30;border-radius:7px;padding:16px;margin-top:14px;}

.overlay{position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(5px);
  display:flex;align-items:center;justify-content:center;z-index:200;padding:20px;}
.modal{background:#0d1322;border:1px solid #1a2a3d;border-radius:12px;padding:28px;
  width:100%;max-width:480px;max-height:90vh;overflow-y:auto;animation:modalIn .2s ease;}
.modal-sm{max-width:380px;}
@keyframes modalIn{from{opacity:0;transform:scale(.96) translateY(8px);}to{opacity:1;transform:scale(1) translateY(0);}}
.modal-title{font-family:'Barlow Condensed',sans-serif;font-size:24px;font-weight:800;margin-bottom:22px;}
.err-box{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.28);border-radius:6px;padding:9px 13px;margin-bottom:16px;font-size:13px;color:#ef4444;}
.field{margin-bottom:17px;}
.field-label{display:block;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.13em;text-transform:uppercase;color:#3d5068;margin-bottom:7px;}
.field-input,.field-textarea{width:100%;padding:10px 12px;background:#090e1a;border:1px solid #1a2a3d;
  border-radius:6px;color:#e2e8f0;font-family:'Barlow',sans-serif;font-size:14px;outline:none;transition:border-color .18s;}
.field-input:focus,.field-textarea:focus{border-color:#f59e0b;}
.field-textarea{resize:vertical;min-height:68px;font-family:'DM Mono',monospace;font-size:12px;line-height:1.5;}
.code-input-row{display:flex;gap:8px;}
.code-input-row .field-input{flex:1;}
.eye-btn{padding:10px 14px;background:transparent;border:1px solid #1a2a3d;border-radius:6px;
  color:#64748b;font-size:12px;font-family:'Barlow',sans-serif;cursor:pointer;flex-shrink:0;transition:all .18s;white-space:nowrap;}
.eye-btn:hover{border-color:#f59e0b;color:#f59e0b;}
.eye-btn-sm{padding:4px 10px;background:transparent;border:1px solid #1a2a3d;border-radius:5px;
  color:#64748b;font-size:11px;font-family:'Barlow',sans-serif;cursor:pointer;transition:all .18s;white-space:nowrap;}
.eye-btn-sm:hover{border-color:#f59e0b;color:#f59e0b;}
.type-toggle-row{display:flex;gap:8px;}
.type-toggle{flex:1;padding:10px 6px;border-radius:7px;border:1.5px solid #1a2a3d;background:#090e1a;
  color:#3d5068;cursor:pointer;transition:all .18s;font-family:'Barlow Condensed',sans-serif;font-size:17px;font-weight:700;letter-spacing:.04em;}
.type-toggle:hover{border-color:#263a52;color:#64748b;}
.tt-ghp.on {border-color:rgba(56,189,248,.5);background:rgba(56,189,248,.1);color:#38bdf8;}
.tt-lawn.on{border-color:rgba(74,222,128,.5);background:rgba(74,222,128,.1);color:#4ade80;}
.tt-tmte.on{border-color:rgba(251,146,60,.5); background:rgba(251,146,60,.1);color:#fb923c;}
.tt-spvr.on{border-color:rgba(192,132,252,.5);background:rgba(192,132,252,.1);color:#c084fc;}
.zip-entry-row{display:flex;gap:8px;}
.zip-entry-row .field-input{flex:1;}
.zip-tags-edit{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px;min-height:24px;}
.zip-tag-edit{display:inline-flex;align-items:center;gap:5px;font-family:'DM Mono',monospace;
  font-size:11px;padding:3px 9px;background:#111a28;border:1px solid #1a2a3d;border-radius:4px;color:#94a3b8;}
.zip-rm{background:none;border:none;color:#3d5068;cursor:pointer;padding:0;font-size:14px;line-height:1;transition:color .15s;}
.zip-rm:hover{color:#ef4444;}
.btn-add-zip{padding:10px 16px;background:#f59e0b;border:none;border-radius:6px;color:#090e1a;
  font-family:'Barlow Condensed',sans-serif;font-size:13px;font-weight:700;cursor:pointer;flex-shrink:0;transition:background .18s;}
.btn-add-zip:hover{background:#fbbf24;}
.modal-footer{display:flex;gap:10px;justify-content:flex-end;margin-top:22px;padding-top:18px;border-top:1px solid #151e30;}
.btn-cancel{padding:9px 18px;background:transparent;border:1px solid #151e30;border-radius:6px;
  color:#64748b;font-family:'Barlow',sans-serif;font-size:14px;cursor:pointer;transition:all .18s;}
.btn-cancel:hover{border-color:#2d3f52;color:#94a3b8;}
.btn-save{padding:9px 20px;background:#f59e0b;border:none;border-radius:6px;color:#090e1a;
  font-family:'Barlow Condensed',sans-serif;font-size:14px;font-weight:700;letter-spacing:.05em;cursor:pointer;transition:background .18s;}
.btn-save:hover{background:#fbbf24;}
.btn-save:disabled{background:#2d3f52;color:#4a5568;cursor:not-allowed;}
.btn-save-full{width:100%;}
@keyframes shake{10%,90%{transform:translate3d(-2px,0,0)}20%,80%{transform:translate3d(3px,0,0)}30%,50%,70%{transform:translate3d(-4px,0,0)}40%,60%{transform:translate3d(4px,0,0)}}
.shake{animation:shake .45s cubic-bezier(.36,.07,.19,.97) both;}
::-webkit-scrollbar{width:5px;}
::-webkit-scrollbar-track{background:#090e1a;}
::-webkit-scrollbar-thumb{background:#151e30;border-radius:3px;}
::-webkit-scrollbar-thumb:hover{background:#1e2e43;}
`;

// ─── BADGES ───────────────────────────────────────────────────────────────────
function StatusBadge({ status }) {
  const cfg = {
    available: { label:"Available", bg:"rgba(34,197,94,.13)",  color:"#22c55e", bd:"rgba(34,197,94,.28)"  },
    "on-call":  { label:"On Call",   bg:"rgba(245,158,11,.13)", color:"#f59e0b", bd:"rgba(245,158,11,.28)" },
    "off-duty": { label:"Off Duty",  bg:"rgba(239,68,68,.13)",  color:"#ef4444", bd:"rgba(239,68,68,.28)"  },
  }[status] || { label:status, bg:"transparent", color:"#94a3b8", bd:"#263047" };
  return (
    <span style={{padding:"2px 9px",borderRadius:20,fontSize:10,fontFamily:"'DM Mono',monospace",
      letterSpacing:"0.08em",textTransform:"uppercase",fontWeight:500,
      background:cfg.bg,color:cfg.color,border:`1px solid ${cfg.bd}`}}>{cfg.label}</span>
  );
}
function TypeBadge({ type, highlight }) {
  const c = TYPE_CFG[type]; if(!c) return null;
  return (
    <span style={{padding:"2px 9px",borderRadius:4,fontSize:10,fontFamily:"'DM Mono',monospace",
      letterSpacing:"0.08em",textTransform:"uppercase",fontWeight:500,transition:"all .18s",
      background:highlight?c.bg:"rgba(255,255,255,.04)",color:highlight?c.color:"#3d5068",
      border:highlight?`1px solid ${c.bd}`:"1px solid #1a2a3d"}}>{type}</span>
  );
}

// ─── TECH CARD ────────────────────────────────────────────────────────────────
function TechCard({ tech, highlightZip, highlightType, index }) {
  return (
    <div className="tech-card" style={{animationDelay:`${index*55}ms`}}>
      <div className="tech-avatar">{ini(tech.name)}</div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:5,flexWrap:"wrap"}}>
          <div className="tech-name">{tech.name}</div>
          <StatusBadge status={tech.status}/>
        </div>
        <a href={`tel:${tech.phone}`} className="tech-phone">{tech.phone}</a>
        {tech.types?.length>0 && (
          <div className="tag-row">
            {tech.types.map(t=><TypeBadge key={t} type={t} highlight={t===highlightType}/>)}
          </div>
        )}
        {tech.notes && <div className="tech-notes">{tech.notes}</div>}
        <div className="zip-tags">
          {[...tech.zipCodes].sort().map(z=>(
            <span key={z} className={`zip-tag${z===highlightZip?" zip-hl":""}`}>{z}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── SEARCH VIEW ─────────────────────────────────────────────────────────────
const TYPE_ACTIVE_CLASS = { GHP:"ghp-active", Lawn:"lawn-active", Termite:"tmte-active", Supervisor:"spvr-active" };
const TYPE_SUB          = { GHP:"General Household", Lawn:"Lawn & Outdoor", Termite:"Termite Control", Supervisor:"Lead / Oversight" };

function SearchView({ techs, zipInput, setZipInput, result, setResult }) {
  const [selType, setSelType] = useState(null);
  const zipReady = zipInput.length === 5;
  const doSearch = (type) => {
    const zip = zipInput.trim();
    if (!zip||zip.length<5||!type) return;
    const matches = techs
      .filter(t=>t.zipCodes.includes(zip)&&(t.types||[]).includes(type))
      .sort((a,b)=>(STATUS_ORDER[a.status]??3)-(STATUS_ORDER[b.status]??3));
    setResult({zip,type,matches});
  };
  const handleType = (type) => { setSelType(type); doSearch(type); };
  return (
    <>
      <div className="search-hero">
        <div className="hero-eyebrow">// Technician Availability</div>
        <h1 className="hero-title">Dispatch Lookup</h1>
        <p className="hero-sub">Enter a ZIP code, then select the service type to find available technicians.</p>
        <div className="search-bar">
          <input className="zip-input" type="text" inputMode="numeric" placeholder="00000"
            value={zipInput} maxLength={5} autoFocus
            onChange={e=>{setZipInput(e.target.value.replace(/\D/g,"").slice(0,5));setResult(null);}}/>
        </div>
        <div className="type-section">
          <div className="type-label">Select service type</div>
          <div className="type-grid">
            {TECH_TYPES.map(type=>(
              <button key={type}
                className={`type-btn${selType===type&&result?` ${TYPE_ACTIVE_CLASS[type]}`:""}`}
                disabled={!zipReady} onClick={()=>handleType(type)}>
                <div className="type-btn-label">{type}</div>
                <div className="type-btn-sub">{TYPE_SUB[type]}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
      {result ? (
        <div className="results-wrap">
          <div className="results-head">
            <span className="results-label">
              <span style={{color:"#f59e0b"}}>{result.zip}</span>&nbsp;·&nbsp;
              <span style={{color:TYPE_CFG[result.type]?.color}}>{result.type}</span>
            </span>
            <span className="results-label" style={{color:"#263047"}}>
              {result.matches.length===0?"no techs found":`${result.matches.length} tech${result.matches.length>1?"s":""} found`}
            </span>
          </div>
          {result.matches.length===0 ? (
            <div className="empty-state">
              <div className="empty-icon">🔍</div>
              <div className="empty-title">No Coverage Found</div>
              <div className="empty-text">No <strong style={{color:TYPE_CFG[result.type]?.color}}>{result.type}</strong> technicians are assigned to ZIP <strong style={{color:"#f59e0b"}}>{result.zip}</strong>.</div>
            </div>
          ) : result.matches.map((tech,i)=>(
            <TechCard key={tech.id} tech={tech} highlightZip={result.zip} highlightType={result.type} index={i}/>
          ))}
        </div>
      ) : !zipReady && (
        <div style={{textAlign:"center",marginTop:48,color:"#151e30"}}>
          <div style={{fontSize:48,marginBottom:10}}>📍</div>
          <div style={{fontFamily:"'DM Mono',monospace",fontSize:11,letterSpacing:"0.13em",textTransform:"uppercase"}}>Start by entering a zip code</div>
        </div>
      )}
    </>
  );
}

// ─── LOGIN MODAL ──────────────────────────────────────────────────────────────
// Checks server on mount whether setup is needed, then handles login or first-time setup.
function LoginModal({ onLogin, onClose }) {
  const [mode,        setMode]        = useState("checking"); // checking | login | setup
  const [code,        setCode]        = useState("");
  const [confirm,     setConfirm]     = useState("");
  const [show,        setShow]        = useState(false);
  const [err,         setErr]         = useState("");
  const [submitting,  setSubmitting]  = useState(false);
  const [shake,       setShake]       = useState(false);

  const triggerShake = () => { setShake(true); setTimeout(()=>setShake(false),500); };

  useEffect(()=>{
    api.auth({ action:"checkStatus" })
      .then(d => setMode(d.needsSetup ? "setup" : "login"))
      .catch(()  => setMode("login"));
  },[]);

  const submit = async () => {
    setSubmitting(true);
    setErr("");
    if (mode==="setup") {
      if (code.length<4)  { setErr("Code must be at least 4 characters."); triggerShake(); setSubmitting(false); return; }
      if (code!==confirm) { setErr("Codes don't match."); triggerShake(); setSubmitting(false); return; }
    }
    const res = await onLogin(mode==="setup" ? "setup" : "login", code);
    if (res==="wrong") { setErr("Incorrect access code."); triggerShake(); setCode(""); }
    else if (res)       { setErr(res); triggerShake(); }
    setSubmitting(false);
  };

  const isSetup   = mode === "setup";
  const isLoading = mode === "checking";

  return (
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&!isSetup&&onClose()}>
      <div className={`modal modal-sm${shake?" shake":""}`}>
        <div style={{textAlign:"center",marginBottom:22}}>
          <div style={{fontSize:38,marginBottom:10}}>{isSetup?"🔐":"🔒"}</div>
          <div style={{fontFamily:"'Barlow Condensed',sans-serif",fontSize:26,fontWeight:800,marginBottom:6}}>
            {isLoading?"Connecting…":isSetup?"Create Master Code":"Admin Access"}
          </div>
          {!isLoading && (
            <div style={{fontSize:13,color:"#3d5068",lineHeight:1.6}}>
              {isSetup
                ?"Create a secure code to protect the admin panel."
                :"Enter your access code to continue."}
            </div>
          )}
        </div>

        {isLoading ? (
          <div style={{textAlign:"center",padding:"20px 0",color:"#3d5068",fontFamily:"'DM Mono',monospace",fontSize:12}}>
            Checking status…
          </div>
        ) : (
          <>
            {err && <div className="err-box">{err}</div>}
            <div className="field">
              <label className="field-label">{isSetup?"New Access Code":"Access Code"}</label>
              <div className="code-input-row">
                <input className="field-input" type={show?"text":"password"} value={code}
                  onChange={e=>{setCode(e.target.value);setErr("");}}
                  onKeyDown={e=>!isSetup&&e.key==="Enter"&&submit()}
                  placeholder={isSetup?"Create a code":"Enter your code"} autoFocus/>
                <button className="eye-btn" onClick={()=>setShow(s=>!s)}>{show?"Hide":"Show"}</button>
              </div>
            </div>
            {isSetup && (
              <div className="field">
                <label className="field-label">Confirm Code</label>
                <div className="code-input-row">
                  <input className="field-input" type={show?"text":"password"} value={confirm}
                    onChange={e=>{setConfirm(e.target.value);setErr("");}}
                    onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="Repeat the code"/>
                </div>
              </div>
            )}
            <div className="modal-footer">
              {!isSetup && <button className="btn-cancel" onClick={onClose}>Cancel</button>}
              <button className={`btn-save${isSetup?" btn-save-full":""}`}
                disabled={submitting} onClick={submit}>
                {submitting?"…":isSetup?"Set Code & Enter Admin":"Enter"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ─── MANAGER CODE MODAL ───────────────────────────────────────────────────────
function ManagerCodeModal({ mode, manager, onSave, onClose }) {
  const [form, setForm] = useState(mode==="edit"?{...manager}:{label:"",code:""});
  const [show, setShow] = useState(false);
  const [err,  setErr]  = useState("");
  const upd = (k,v) => setForm(f=>({...f,[k]:v}));
  const submit = () => {
    if (!form.label.trim()) { setErr("Label is required."); return; }
    if (form.code.length<4) { setErr("Code must be at least 4 characters."); return; }
    onSave(form);
  };
  return (
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal modal-sm">
        <div className="modal-title">{mode==="edit"?"Edit Manager Code":"Add Manager Code"}</div>
        {err && <div className="err-box">{err}</div>}
        <div className="field">
          <label className="field-label">Label</label>
          <input className="field-input" value={form.label} onChange={e=>{upd("label",e.target.value);setErr("");}} placeholder="e.g. John Martinez" autoFocus/>
        </div>
        <div className="field">
          <label className="field-label">Access Code</label>
          <div className="code-input-row">
            <input className="field-input" type={show?"text":"password"} value={form.code}
              onChange={e=>{upd("code",e.target.value);setErr("");}}
              onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="Min. 4 characters"/>
            <button className="eye-btn" onClick={()=>setShow(s=>!s)}>{show?"Hide":"Show"}</button>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-save" onClick={submit}>{mode==="edit"?"Save Changes":"Add Code"}</button>
        </div>
      </div>
    </div>
  );
}

// ─── CODE MANAGER ─────────────────────────────────────────────────────────────
// Fetches full auth config from server on mount (master code required).
// All saves go back through the API.
function CodeManager({ authCode, onMasterCodeChanged }) {
  const [cfg,         setCfg]         = useState(null);
  const [cfgLoading,  setCfgLoading]  = useState(true);
  const [cfgErr,      setCfgErr]      = useState("");
  const [showMaster,  setShowMaster]  = useState(false);
  const [changing,    setChanging]    = useState(false);
  const [newCode,     setNewCode]     = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [showNew,     setShowNew]     = useState(false);
  const [masterErr,   setMasterErr]   = useState("");
  const [saving,      setSaving]      = useState(false);
  const [codeModal,   setCodeModal]   = useState(null);
  const [confirmDel,  setConfirmDel]  = useState(null);

  useEffect(()=>{
    api.auth({ action:"getConfig", code:authCode })
      .then(d => { if(d.error) throw new Error(d.error); setCfg(d); })
      .catch(e => setCfgErr(e.message))
      .finally(()=> setCfgLoading(false));
  },[authCode]);

  const saveConfig = async (newCfg) => {
    setSaving(true);
    const res = await api.auth({ action:"updateConfig", code:authCode, config:newCfg });
    setSaving(false);
    if (res.error) { setMasterErr(res.error); return false; }
    setCfg(newCfg);
    return true;
  };

  const saveMaster = async () => {
    if (newCode.length<4)      { setMasterErr("Code must be at least 4 characters."); return; }
    if (newCode!==confirmCode) { setMasterErr("Codes don't match."); return; }
    const ok = await saveConfig({...cfg, master:newCode});
    if (ok) {
      onMasterCodeChanged(newCode); // keep parent in sync
      setChanging(false); setNewCode(""); setConfirmCode(""); setMasterErr("");
    }
  };

  const handleSaveMgr = async (data) => {
    const updated = codeModal?.mode==="edit"
      ? cfg.managers.map(m=>m.id===data.id?data:m)
      : [...cfg.managers, {...data, id:mid()}];
    const ok = await saveConfig({...cfg, managers:updated});
    if (ok) setCodeModal(null);
  };

  const handleDelMgr = async (id) => {
    if (confirmDel===id) {
      await saveConfig({...cfg, managers:cfg.managers.filter(m=>m.id!==id)});
      setConfirmDel(null);
    } else {
      setConfirmDel(id);
      setTimeout(()=>setConfirmDel(p=>p===id?null:p),3000);
    }
  };

  if (cfgLoading) return (
    <div style={{padding:"40px 20px",textAlign:"center",color:"#3d5068",fontFamily:"'DM Mono',monospace",fontSize:12}}>
      Loading access codes…
    </div>
  );
  if (cfgErr) return (
    <div className="err-box" style={{marginTop:16}}>Failed to load access codes: {cfgErr}</div>
  );
  if (!cfg) return null;

  return (
    <div>
      {/* ── Master Code ── */}
      <div className="code-section">
        <div className="code-section-title">Master Code</div>
        <div className="code-section-sub">Full access + manages all codes. Keep private.</div>
        {!changing ? (
          <div className="code-row-display">
            <span className="code-masked">{showMaster?cfg.master:"●".repeat(Math.min(cfg.master.length,14))}</span>
            <button className="eye-btn-sm" onClick={()=>setShowMaster(s=>!s)}>{showMaster?"Hide":"Show"}</button>
            <button className="btn-edit" onClick={()=>setChanging(true)}>Change</button>
          </div>
        ) : (
          <div className="change-form-wrap">
            {masterErr && <div className="err-box" style={{marginBottom:12}}>{masterErr}</div>}
            <div style={{display:"flex",gap:10,marginBottom:12,flexWrap:"wrap"}}>
              <div style={{flex:1,minWidth:140}}>
                <div className="field-label" style={{marginBottom:6}}>New Code</div>
                <input className="field-input" type={showNew?"text":"password"} value={newCode}
                  onChange={e=>{setNewCode(e.target.value);setMasterErr("");}} placeholder="New code" autoFocus/>
              </div>
              <div style={{flex:1,minWidth:140}}>
                <div className="field-label" style={{marginBottom:6}}>Confirm Code</div>
                <input className="field-input" type={showNew?"text":"password"} value={confirmCode}
                  onChange={e=>{setConfirmCode(e.target.value);setMasterErr("");}}
                  onKeyDown={e=>e.key==="Enter"&&saveMaster()} placeholder="Repeat code"/>
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <button className="eye-btn-sm" onClick={()=>setShowNew(s=>!s)}>{showNew?"Hide":"Show"} codes</button>
              <div style={{flex:1}}/>
              <button className="btn-cancel" onClick={()=>{setChanging(false);setMasterErr("");setNewCode("");setConfirmCode("");}}>Cancel</button>
              <button className="btn-save" disabled={saving} onClick={saveMaster}>{saving?"Saving…":"Save New Code"}</button>
            </div>
          </div>
        )}
      </div>

      {/* ── Manager Codes ── */}
      <div className="code-section" style={{marginTop:20}}>
        <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,marginBottom:4}}>
          <div>
            <div className="code-section-title">Manager Codes</div>
            <div className="code-section-sub" style={{marginBottom:0}}>Full technician access. Cannot view or change access codes.</div>
          </div>
          <button className="btn-add" style={{flexShrink:0,marginTop:2}} onClick={()=>setCodeModal("add")}>+ Add Code</button>
        </div>
        {cfg.managers.length===0 ? (
          <div style={{padding:"28px 20px",textAlign:"center",border:"1px dashed #151e30",borderRadius:8,marginTop:16}}>
            <div style={{color:"#3d5068",fontSize:12,fontFamily:"'DM Mono',monospace",letterSpacing:".06em"}}>No manager codes yet</div>
          </div>
        ) : (
          <div className="table-wrap" style={{marginTop:16}}>
            <table className="tech-table">
              <thead><tr><th>Label</th><th>Code</th><th></th></tr></thead>
              <tbody>
                {cfg.managers.map(mgr=>(
                  <ManagerRow key={mgr.id} mgr={mgr}
                    onEdit={()=>setCodeModal({mode:"edit",manager:mgr})}
                    onDelete={()=>handleDelMgr(mgr.id)}
                    isConfirming={confirmDel===mgr.id}/>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {codeModal && (
        <ManagerCodeModal mode={codeModal==="add"?"add":"edit"} manager={codeModal?.manager}
          onSave={handleSaveMgr} onClose={()=>setCodeModal(null)}/>
      )}
    </div>
  );
}

function ManagerRow({ mgr, onEdit, onDelete, isConfirming }) {
  const [show, setShow] = useState(false);
  return (
    <tr>
      <td style={{fontFamily:"'Barlow Condensed',sans-serif",fontSize:17,fontWeight:700}}>{mgr.label}</td>
      <td>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontFamily:"'DM Mono',monospace",fontSize:13,color:"#94a3b8",letterSpacing:".1em"}}>
            {show?mgr.code:"●".repeat(Math.min(mgr.code.length,12))}
          </span>
          <button className="eye-btn-sm" onClick={()=>setShow(s=>!s)}>{show?"Hide":"Show"}</button>
        </div>
      </td>
      <td>
        <div style={{display:"flex",gap:7}}>
          <button className="btn-edit" onClick={onEdit}>Edit</button>
          <button className={isConfirming?"btn-del-confirm":"btn-del"} onClick={onDelete}>{isConfirming?"Confirm?":"Delete"}</button>
        </div>
      </td>
    </tr>
  );
}

// ─── ADMIN VIEW ───────────────────────────────────────────────────────────────
function AdminView({ techs, confirmId, authLevel, authLabel, authCode,
                     onSignOut, onMasterCodeChanged,
                     onAdd, onEdit, onDelete, onImport, saveStatus }) {
  const [tab,           setTab]           = useState("techs");
  const [importPending, setImportPending] = useState(null);
  const [importErr,     setImportErr]     = useState("");
  const fileRef = useRef(null);
  const uniqueZips = new Set(techs.flatMap(t=>t.zipCodes)).size;

  const handleExport = () => {
    const blob = new Blob([JSON.stringify({app:"PestDispatch",version:1,exportedAt:new Date().toISOString(),technicians:techs},null,2)],{type:"application/json"});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href=url; a.download=`pestdispatch-${new Date().toISOString().slice(0,10)}.json`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0]; if(!file) return;
    setImportErr("");
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        const list = data.technicians ?? data;
        if (!Array.isArray(list)||list.length===0) throw new Error("No technicians found.");
        const valid = list.filter(t=>t.name&&t.phone);
        if (!valid.length) throw new Error("File contains no valid technician records.");
        setImportPending({techs:valid,filename:file.name});
      } catch(err) { setImportErr(`Could not read file: ${err.message}`); }
    };
    reader.readAsText(file); e.target.value="";
  };

  return (
    <div className="admin-view">
      <div className="admin-head">
        <div className="admin-head-left">
          <h2 className="admin-title">Admin Panel</h2>
          {tab==="techs" && (
            <div className="admin-meta">
              <span>{techs.length}</span> technicians&nbsp;·&nbsp;<span>{uniqueZips}</span> unique ZIP codes
            </div>
          )}
        </div>
        <div className="admin-head-right">
          {/* Save status indicator */}
          {saveStatus && (
            <div className={`save-toast ${saveStatus==="saving"?"save-saving":saveStatus==="ok"?"save-ok":"save-err"}`}>
              {saveStatus==="saving"?"Saving…":saveStatus==="ok"?"✓ Saved":"✗ Save failed"}
            </div>
          )}
          <div className="session-badge">
            <span className="session-dot" style={{background:authLevel==="master"?"#f59e0b":"#38bdf8"}}/>
            {authLabel}
          </div>
          <button className="btn-signout" onClick={onSignOut}>Sign Out</button>
          {tab==="techs" && <>
            <button className="btn-outline" onClick={handleExport}>↓ Export</button>
            <button className="btn-outline" onClick={()=>fileRef.current?.click()}>↑ Import</button>
            <input ref={fileRef} type="file" accept=".json" style={{display:"none"}} onChange={handleFileChange}/>
            <button className="btn-add" onClick={onAdd}>+ Add Technician</button>
          </>}
        </div>
      </div>

      {authLevel==="master" && (
        <div className="admin-tabs">
          <button className={`admin-tab${tab==="techs"?" tab-active":""}`} onClick={()=>setTab("techs")}>Technicians</button>
          <button className={`admin-tab${tab==="codes"?" tab-active":""}`} onClick={()=>setTab("codes")}>🔐 Access Codes</button>
        </div>
      )}

      {tab==="techs" && (
        <>
          {importErr && (
            <div className="err-box" style={{marginBottom:16}}>
              {importErr}&nbsp;<span style={{cursor:"pointer",textDecoration:"underline"}} onClick={()=>setImportErr("")}>Dismiss</span>
            </div>
          )}
          {importPending && (
            <div className="import-banner">
              <div className="import-banner-title">📁 {importPending.filename}</div>
              <div className="import-banner-sub">
                <strong style={{color:"#f59e0b"}}>{importPending.techs.length} technicians</strong> found.
                This will replace your current {techs.length} technician{techs.length!==1?"s":""}. Cannot be undone.
              </div>
              <div className="import-banner-actions">
                <button className="btn-cancel" onClick={()=>setImportPending(null)}>Cancel</button>
                <button className="btn-save" onClick={()=>{onImport(importPending.techs);setImportPending(null);}}>Yes, Replace All</button>
              </div>
            </div>
          )}

          {techs.length===0 ? (
            <div className="empty-state">
              <div className="empty-icon">👷</div>
              <div className="empty-title">No Technicians Yet</div>
              <div className="empty-text">Add your first technician above, or import from a backup file.</div>
            </div>
          ) : (
            <div className="table-wrap">
              <table className="tech-table">
                <thead>
                  <tr><th>Technician</th><th>Phone</th><th>Status</th><th>Service Types</th><th>ZIP Codes</th><th>Notes</th><th></th></tr>
                </thead>
                <tbody>
                  {techs.map(tech=>(
                    <tr key={tech.id}>
                      <td>
                        <div style={{display:"flex",alignItems:"center",gap:9}}>
                          <div className="row-avatar">{ini(tech.name)}</div>
                          <span style={{fontFamily:"'Barlow Condensed',sans-serif",fontSize:17,fontWeight:700}}>{tech.name}</span>
                        </div>
                      </td>
                      <td style={{fontFamily:"'DM Mono',monospace",fontSize:12,color:"#64748b"}}>{tech.phone}</td>
                      <td><StatusBadge status={tech.status}/></td>
                      <td>
                        <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                          {(tech.types||[]).map(t=><TypeBadge key={t} type={t} highlight/>)}
                          {(!tech.types||tech.types.length===0)&&<span style={{color:"#263047",fontSize:12}}>—</span>}
                        </div>
                      </td>
                      <td><div className="zip-tags">{[...tech.zipCodes].sort().map(z=><span key={z} className="zip-tag">{z}</span>)}</div></td>
                      <td style={{color:"#3d5068",fontSize:13,maxWidth:160}}>{tech.notes||"—"}</td>
                      <td>
                        <div style={{display:"flex",gap:7}}>
                          <button className="btn-edit" onClick={()=>onEdit(tech)}>Edit</button>
                          <button className={confirmId===tech.id?"btn-del-confirm":"btn-del"} onClick={()=>onDelete(tech.id)}>
                            {confirmId===tech.id?"Confirm?":"Delete"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}

      {tab==="codes" && authLevel==="master" && (
        <CodeManager authCode={authCode} onMasterCodeChanged={onMasterCodeChanged}/>
      )}
    </div>
  );
}

// ─── TECH MODAL ───────────────────────────────────────────────────────────────
const TT_CLASS = { GHP:"tt-ghp", Lawn:"tt-lawn", Termite:"tt-tmte", Supervisor:"tt-spvr" };
function TechModal({ mode, tech, onSave, onClose }) {
  const blank = {name:"",phone:"",status:"available",types:[],zipCodes:[],notes:""};
  const [form,     setForm]     = useState(mode==="edit"?{...tech,types:tech.types||[]}:blank);
  const [zipEntry, setZipEntry] = useState("");
  const [err,      setErr]      = useState("");
  const upd = (k,v) => setForm(f=>({...f,[k]:v}));
  const toggleType = (type) => upd("types",form.types.includes(type)?form.types.filter(t=>t!==type):[...form.types,type]);
  const addZip = () => {
    const z = zipEntry.trim().replace(/\D/g,"").slice(0,5);
    if (z.length!==5||form.zipCodes.includes(z)) { setZipEntry(""); return; }
    upd("zipCodes",[...form.zipCodes,z]); setZipEntry("");
  };
  const submit = () => {
    if (!form.name.trim())     { setErr("Name is required."); return; }
    if (!form.phone.trim())    { setErr("Phone is required."); return; }
    if (!form.types.length)    { setErr("Select at least one service type."); return; }
    onSave(form);
  };
  return (
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal">
        <div className="modal-title">{mode==="edit"?"Edit Technician":"Add Technician"}</div>
        {err && <div className="err-box">{err}</div>}
        <div className="field">
          <label className="field-label">Full Name</label>
          <input className="field-input" value={form.name} onChange={e=>{upd("name",e.target.value);setErr("");}} placeholder="e.g. John Smith"/>
        </div>
        <div className="field">
          <label className="field-label">Phone Number</label>
          <input className="field-input" value={form.phone} onChange={e=>{upd("phone",e.target.value);setErr("");}} placeholder="(555) 000-0000"/>
        </div>
        <div className="field">
          <label className="field-label">Status</label>
          <select className="field-input" value={form.status} onChange={e=>upd("status",e.target.value)}>
            <option value="available">Available</option>
            <option value="on-call">On Call</option>
            <option value="off-duty">Off Duty</option>
          </select>
        </div>
        <div className="field">
          <label className="field-label">Service Types — select all that apply</label>
          <div className="type-toggle-row">
            {TECH_TYPES.map(type=>(
              <button key={type} className={`type-toggle ${TT_CLASS[type]}${form.types.includes(type)?" on":""}`}
                onClick={()=>{toggleType(type);setErr("");}}>
                {type}
              </button>
            ))}
          </div>
        </div>
        <div className="field">
          <label className="field-label">Service ZIP Codes</label>
          <div className="zip-entry-row">
            <input className="field-input" value={zipEntry} onChange={e=>setZipEntry(e.target.value.replace(/\D/g,"").slice(0,5))}
              onKeyDown={e=>e.key==="Enter"&&addZip()} placeholder="Type ZIP + Enter" maxLength={5}/>
            <button className="btn-add-zip" onClick={addZip}>Add</button>
          </div>
          <div className="zip-tags-edit">
            {form.zipCodes.length===0
              ? <span style={{fontSize:12,color:"#263047",fontFamily:"'DM Mono',monospace"}}>No ZIPs assigned yet</span>
              : [...form.zipCodes].sort().map(z=>(
                  <span key={z} className="zip-tag-edit">
                    {z}<button className="zip-rm" onClick={()=>upd("zipCodes",form.zipCodes.filter(x=>x!==z))}>×</button>
                  </span>
                ))
            }
          </div>
        </div>
        <div className="field">
          <label className="field-label">Notes / Specialties</label>
          <textarea className="field-textarea" value={form.notes} onChange={e=>upd("notes",e.target.value)} placeholder="e.g. Commercial accounts, high-rise..."/>
        </div>
        <div className="modal-footer">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-save" onClick={submit}>{mode==="edit"?"Save Changes":"Add Technician"}</button>
        </div>
      </div>
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [techs,      setTechs]      = useState([]);
  const [ready,      setReady]      = useState(false);
  const [loadErr,    setLoadErr]    = useState(false);
  const [view,       setView]       = useState("search");
  const [zipInput,   setZipInput]   = useState("");
  const [result,     setResult]     = useState(null);
  const [modal,      setModal]      = useState(null);
  const [confirmId,  setConfirmId]  = useState(null);
  const [authLevel,  setAuthLevel]  = useState(null);
  const [authLabel,  setAuthLabel]  = useState("");
  const [authCode,   setAuthCode]   = useState("");   // kept in memory for API writes
  const [showLogin,  setShowLogin]  = useState(false);
  const [saveStatus, setSaveStatus] = useState(null); // null | "saving" | "ok" | "err"

  // ── Load technicians from API on mount ─────────────────────────────────────
  const loadTechs = useCallback(async () => {
    setLoadErr(false);
    try {
      const data = await api.getTechs();
      setTechs(Array.isArray(data) ? data : []);
    } catch {
      setLoadErr(true);
    }
    setReady(true);
  }, []);

  useEffect(() => { loadTechs(); }, [loadTechs]);

  // ── Persist technicians to API (optimistic) ────────────────────────────────
  const persistTechs = useCallback(async (next, code) => {
    setTechs(next);
    setSaveStatus("saving");
    try {
      const res = await api.saveTechs(next, code);
      setSaveStatus(res.ok ? "ok" : "err");
    } catch {
      setSaveStatus("err");
    }
    setTimeout(() => setSaveStatus(null), 2500);
  }, []);

  // ── Auth ───────────────────────────────────────────────────────────────────
  const handleAdminClick = () => { authLevel ? setView("admin") : setShowLogin(true); };

  const handleLogin = async (action, code) => {
    const data = await api.auth({ action: action === "setup" ? "setup" : "login", code });
    if (data.needsSetup) return "needsSetup"; // shouldn't reach here (modal handles it)
    if (data.error === "wrong") return "wrong";
    if (data.error) return data.error;
    setAuthLevel(data.level);
    setAuthLabel(data.label);
    setAuthCode(code);
    setShowLogin(false);
    setView("admin");
    return null;
  };

  const handleSignOut = () => {
    setAuthLevel(null); setAuthLabel(""); setAuthCode(""); setView("search");
  };

  // When master changes their own code, keep authCode in sync
  const handleMasterCodeChanged = useCallback((newCode) => {
    setAuthCode(newCode);
  }, []);

  // ── Technician CRUD ────────────────────────────────────────────────────────
  const handleSaveTech = (data) => {
    const next = modal?.mode==="edit"
      ? techs.map(t=>t.id===data.id?data:t)
      : [...techs,{...data,id:uid()}];
    persistTechs(next, authCode);
    setModal(null);
  };

  const handleDelete = (id) => {
    if (confirmId===id) {
      persistTechs(techs.filter(t=>t.id!==id), authCode);
      setConfirmId(null);
    } else {
      setConfirmId(id);
      setTimeout(()=>setConfirmId(p=>p===id?null:p),3000);
    }
  };

  const handleImport = (newTechs) => {
    persistTechs(newTechs.map(t=>({...t,id:t.id||uid()})), authCode);
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  if (!ready) return (
    <div style={{minHeight:"100vh",background:"#090e1a",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16}}>
      <div style={{fontFamily:"'DM Mono',monospace",fontSize:13,color:"#263047"}}>Connecting to database…</div>
    </div>
  );

  if (loadErr) return (
    <div style={{minHeight:"100vh",background:"#090e1a",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16}}>
      <div style={{fontSize:36}}>⚠️</div>
      <div style={{fontFamily:"'Barlow Condensed',sans-serif",fontSize:24,fontWeight:700}}>Connection Failed</div>
      <div style={{fontSize:13,color:"#3d5068",maxWidth:300,textAlign:"center",lineHeight:1.6}}>Could not reach the database. Check your environment variables and Supabase project status.</div>
      <button className="btn-add" onClick={loadTechs}>Retry</button>
    </div>
  );

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <header className="top-bar">
          <div className="brand">
            <div className="brand-icon">🐛</div>
            <div className="brand-name">PEST<span>DISPATCH</span></div>
          </div>
          <nav style={{display:"flex",gap:8}}>
            <button className={`nav-pill${view==="search"?" nav-active":""}`}
              onClick={()=>{setView("search");setResult(null);setZipInput("");}}>Lookup</button>
            <button className={`nav-pill${view==="admin"?" nav-active":""}`} onClick={handleAdminClick}>
              {!authLevel&&<span style={{marginRight:5,fontSize:11,opacity:.7}}>🔒</span>}Manage Techs
            </button>
          </nav>
        </header>

        {view==="search"
          ? <SearchView techs={techs} zipInput={zipInput} setZipInput={setZipInput} result={result} setResult={setResult}/>
          : <AdminView  techs={techs} confirmId={confirmId} authLevel={authLevel} authLabel={authLabel}
              authCode={authCode} onSignOut={handleSignOut} onMasterCodeChanged={handleMasterCodeChanged}
              onAdd={()=>setModal({mode:"add"})} onEdit={t=>setModal({mode:"edit",tech:t})}
              onDelete={handleDelete} onImport={handleImport} saveStatus={saveStatus}/>
        }

        {modal     && <TechModal  mode={modal.mode} tech={modal.tech} onSave={handleSaveTech} onClose={()=>setModal(null)}/>}
        {showLogin && <LoginModal onLogin={handleLogin} onClose={()=>setShowLogin(false)}/>}
      </div>
    </>
  );
}
